<?php

namespace App\Filament\Resources\KehadiranResource\Pages;

use App\Filament\Resources\KehadiranResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKehadiran extends CreateRecord
{
    protected static string $resource = KehadiranResource::class;
}
