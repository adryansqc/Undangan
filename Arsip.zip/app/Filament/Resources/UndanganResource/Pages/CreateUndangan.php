<?php

namespace App\Filament\Resources\UndanganResource\Pages;

use App\Filament\Resources\UndanganResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUndangan extends CreateRecord
{
    protected static string $resource = UndanganResource::class;
}
