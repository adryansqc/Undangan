<?php

namespace App\Filament\Resources\CeritaKamiResource\Pages;

use App\Filament\Resources\CeritaKamiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCeritaKami extends CreateRecord
{
    protected static string $resource = CeritaKamiResource::class;
}
